"""Local browser interface. Credentials remain in Python process memory."""
import argparse
import json
import logging
import os
import secrets
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from bitrix_export import Client, ApiError, activity_id, boundary, export

ROOT = Path(__file__).resolve().parent


def make_args(data, output):
    def number(key):
        raw = data.get(key, '')
        if raw == '':
            return None
        n = int(raw)
        if n < 0:
            raise ValueError()
        return n
    low, high = number('min_duration'), number('max_duration')
    since = boundary(data.get('date_from'))
    until = boundary(data.get('date_to'), end=True)
    if since and until and since >= until or low is not None and high is not None and low > high:
        raise ValueError()
    phone = str(data.get('phone', '')).strip()
    if phone and not any(c.isdigit() for c in phone):
        raise ValueError()
    return argparse.Namespace(manager=str(data.get('manager', '')).strip(), since=since, until=until,
                              min_duration=low, max_duration=high, phone=phone,
                              call=activity_id(str(data['call']).strip()) if data.get('call') else None,
                              output=str(output), include_unavailable=False)


def handler_factory(client, token):
    state = {'status': 'idle', 'message': 'Выберите критерии и запустите выгрузку.'}
    lock = threading.Lock()
    output = ROOT / 'exports' / 'web_calls.csv'

    def work(args, request_client):
        try:
            code = export(request_client, args)
            message = 'CSV готов.' if code == 0 else 'CSV готов, но часть запросов завершилась ошибкой. Проверьте журнал.'
            result = {'status': 'done', 'message': message}
        except (ApiError, ValueError):
            result = {'status': 'error', 'message': 'Не удалось получить данные. Проверьте ФИО, права вебхука и доступность портала.'}
        except Exception:
            result = {'status': 'error', 'message': 'Не удалось завершить выгрузку. Проверьте доступ к файлам и журнал.'}
        with lock:
            state.update(result)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Never log URLs, query strings or request contents.

        def send(self, code, content, mime='application/json; charset=utf-8'):
            if isinstance(content, dict):
                content = json.dumps(content, ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers()
            self.wfile.write(content)

        def authorized(self):
            host = f'127.0.0.1:{self.server.server_port}'
            return (self.headers.get('Host') == host
                    and self.headers.get('Origin', 'http://' + host) == 'http://' + host
                    and secrets.compare_digest(self.headers.get('X-Session', ''), token))

        def do_GET(self):
            path = urlsplit(self.path).path
            if path == '/':
                if self.headers.get('Host') != f'127.0.0.1:{self.server.server_port}':
                    return self.send(403, {})
                return self.send(200, (ROOT / 'web' / 'index.html').read_bytes(), 'text/html; charset=utf-8')
            if path == '/browser_export.js':
                return self.send(200, (ROOT / 'web' / 'browser_export.js').read_bytes(), 'text/javascript; charset=utf-8')
            if not self.authorized():
                return self.send(403, {})
            if path == '/status':
                with lock:
                    return self.send(200, dict(state))
            if path == '/download':
                with lock:
                    if state['status'] != 'done':
                        return self.send(409, {})
                    return self.send(200, output.read_bytes(), 'text/csv; charset=utf-8')
            self.send(404, {})

        def do_POST(self):
            if not self.authorized() or self.path != '/export':
                return self.send(403, {})
            try:
                length = int(self.headers.get('Content-Length', 0))
                if not 0 < length <= 8192:
                    raise ValueError()
                data = json.loads(self.rfile.read(length))
                args = make_args(data, output)
                request_client = Client(str(data.get('webhook', ''))) if data.get('webhook') else client
                if request_client is None:
                    raise ValueError()
            except Exception:
                return self.send(400, {'message': 'Проверьте вебхук, даты, длительность, телефон и ID дела.'})
            with lock:
                if state['status'] == 'running':
                    return self.send(409, {'message': 'Выгрузка уже выполняется.'})
                state.update(status='running', message='Ищем звонки и проверяем готовые расшифровки…')
            threading.Thread(target=work, args=(args, request_client), daemon=True).start()
            self.send(202, {'status': 'running'})
    return Handler


def main():
    logging.basicConfig(filename=ROOT / 'export.log', encoding='utf-8', level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    client = None
    token = secrets.token_urlsafe(32)
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler_factory(client, token))
    url = f'http://127.0.0.1:{server.server_port}/#' + token
    print(f'Откройте в браузере: {url}')
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    print('Вебхук хранится только в памяти. Для остановки нажмите Ctrl+C.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
