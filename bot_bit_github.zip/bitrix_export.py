"""Read-only Bitrix24 CRM call exporter. Python 3.10+, standard library only."""
import argparse
import csv
import getpass
import json
import logging
import os
import random
import re
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler


class ApiError(Exception):
    pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Client:
    def __init__(self, webhook, rate=1.0, retries=5):
        u = urlsplit(webhook.strip())
        if (u.scheme != 'https' or not u.hostname or u.username or u.password
                or u.query or u.fragment
                or not re.fullmatch(r'/rest/\d+/[A-Za-z0-9_-]+/?', u.path)):
            raise ValueError('Нужен HTTPS URL входящего вебхука /rest/USER/SECRET/.')
        self.base = webhook.strip().rstrip('/') + '/'
        self.origin = f'https://{u.netloc}'
        self.interval = 1 / rate
        self.retries = retries
        self.last = 0
        self.opener = build_opener(NoRedirect())

    def call(self, method, params):
        for attempt in range(self.retries + 1):
            time.sleep(max(0, self.interval - (time.monotonic() - self.last)))
            self.last = time.monotonic()
            req = Request(self.base + method + '.json',
                          json.dumps(params).encode(),
                          {'Content-Type': 'application/json'}, method='POST')
            retry = False
            code = 'NETWORK_ERROR'
            delay = 0
            try:
                with self.opener.open(req, timeout=60) as response:
                    data = json.load(response)
                if not isinstance(data, dict):
                    raise ApiError('INVALID_RESPONSE')
                if 'error' not in data:
                    return data
                # Never expose server descriptions, URLs, request bodies or raw errors.
                raw = str(data.get('error', ''))
                allowed = {'QUERY_LIMIT_EXCEEDED', 'OPERATION_TIME_LIMIT',
                           'INTERNAL_SERVER_ERROR', 'ERROR_UNEXPECTED_ANSWER',
                           'ACCESS_DENIED', 'NOT_FOUND', 'INVALID_CREDENTIALS',
                           'NO_AUTH_FOUND', 'insufficient_scope', 'ERROR_METHOD_NOT_FOUND'}
                code = raw if raw in allowed else 'API_ERROR'
                retry = code in {'QUERY_LIMIT_EXCEEDED', 'OPERATION_TIME_LIMIT',
                                 'INTERNAL_SERVER_ERROR', 'ERROR_UNEXPECTED_ANSWER'}
            except HTTPError as exc:
                code = f'HTTP_{exc.code}'
                retry = exc.code in {429, 500, 502, 503, 504}
                try:
                    delay = min(300, max(0, float(exc.headers.get('Retry-After', 0))))
                except (ValueError, TypeError):
                    pass
                exc.close()
            except (URLError, TimeoutError, OSError):
                retry = True
            except (ValueError, UnicodeError):
                code = 'INVALID_JSON'
            if not retry or attempt == self.retries:
                raise ApiError(code)
            logging.warning('Повтор %s: %s (%d)', method, code, attempt + 1)
            time.sleep(max(delay, min(60, 2 ** attempt) + random.random()))
        raise ApiError('RETRIES_EXHAUSTED')

    def pages(self, method, params):
        start = 0
        seen = set()
        while True:
            if start in seen:
                raise ApiError('PAGINATION_LOOP')
            seen.add(start)
            data = self.call(method, dict(params, start=start))
            rows = data.get('result')
            if not isinstance(rows, list):
                raise ApiError('INVALID_LIST_RESPONSE')
            yield from rows
            if data.get('next') is None:
                break
            start = int(data['next'])


def activity_id(value):
    if value.isdigit() and int(value) > 0:
        return int(value)
    u = urlsplit(value)
    if u.scheme in {'http', 'https'} and '/rest/' not in u.path:
        m = re.search(r'(?:/crm/activity/(?:details/)?|[?&]activity_id=)(\d+)', value, re.I)
        if not m and u.path.startswith('/crm/activity/'):
            m = re.search(r'[?&]id=(\d+)', value, re.I)
        if m and int(m[1]) > 0:
            return int(m[1])
    raise argparse.ArgumentTypeError('Укажите ID CRM-дела или ссылку /crm/activity/...; ID телефонии — другой идентификатор.')


def boundary(value, end=False, offset='+03:00'):
    if not value:
        return None
    d = datetime.fromisoformat(value)
    if len(value) == 10 and end:
        d += timedelta(days=1)
    if d.tzinfo is None:
        d = d.replace(tzinfo=datetime.fromisoformat('2000-01-01T00:00:00' + offset).tzinfo)
    return d


def safe_cell(value):
    value = '' if value is None else str(value)
    # Protect Excel from formula injection, including whitespace-prefixed formulas.
    return "'" + value if value.lstrip().startswith(('=', '+', '-', '@')) or value.startswith(('\t', '\r', '\n')) else value


FIELDS = ['activity_id', 'activity_url', 'manager_id', 'manager_name', 'start_time',
          'phone', 'duration_seconds', 'duration_source', 'call_ids', 'record_file_ids',
          'owner_type_id', 'owner_id', 'subject', 'transcript_status', 'error_code', 'transcription']


def export(client, args):
    users = {}
    for u in client.pages('user.get', {'sort': 'ID', 'order': 'ASC'}):
        users[str(u['ID'])] = ' '.join(str(u.get(k) or '') for k in ('LAST_NAME', 'NAME', 'SECOND_NAME')).strip()
    manager_ids = None
    if args.manager:
        tokens = args.manager.casefold().split()
        manager_ids = [uid for uid, name in users.items() if all(t in name.casefold() for t in tokens)]
        if not manager_ids:
            raise ValueError('Менеджер не найден. Проверьте ФИО и права user.')
    f = {'TYPE_ID': 2}
    if manager_ids:
        f['RESPONSIBLE_ID'] = manager_ids
    if args.call:
        f['ID'] = args.call
    if args.since:
        f['>=START_TIME'] = args.since.isoformat()
    if args.until:
        f['<START_TIME'] = args.until.isoformat()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    partial = output.with_suffix(output.suffix + '.partial')
    count = errors = skipped = 0
    seen = set()
    phone_filter = re.sub(r'\D', '', args.phone or '')
    with partial.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS, delimiter=';')
        writer.writeheader()
        calls = client.pages('crm.activity.list', {'filter': f, 'order': {'ID': 'ASC'},
                             'select': ['*', 'COMMUNICATIONS']})
        for a in calls:
            aid = str(a['ID'])
            if aid in seen:
                continue
            seen.add(aid)
            phone = ', '.join(str(c.get('VALUE') or '') for c in a.get('COMMUNICATIONS', [])
                              if c.get('TYPE', 'PHONE') == 'PHONE')
            stats = list(client.pages('voximplant.statistic.get',
                         {'FILTER': {'CRM_ACTIVITY_ID': aid}, 'SORT': 'ID', 'ORDER': 'ASC'}))
            phones = [str(s.get('PHONE_NUMBER') or '') for s in stats] + [phone]
            if phone_filter and not any(phone_filter in re.sub(r'\D', '', p) for p in phones):
                continue
            durations = [int(s['CALL_DURATION']) for s in stats if s.get('CALL_DURATION') is not None]
            # Transfers can yield several rows: use longest leg, never sum overlapping legs.
            duration = max(durations) if durations else None
            if args.min_duration is not None and (duration is None or duration < args.min_duration):
                continue
            if args.max_duration is not None and (duration is None or duration > args.max_duration):
                continue
            status, error, text = 'unavailable', '', ''
            try:
                result = client.call('crm.activity.call.getTranscript', {'activityId': int(aid)})['result']
                if result is not None:
                    if not isinstance(result, dict) or not isinstance(result.get('transcription'), str):
                        raise ApiError('INVALID_TRANSCRIPT_RESPONSE')
                    text = result['transcription']
                    status = 'ready' if text.strip() else 'unavailable'
            except ApiError as exc:
                status, error = 'error', str(exc)
                errors += 1
                logging.warning('Ошибка расшифровки дела %s: %s', aid, error)
            if not getattr(args, 'include_unavailable', False) and status != 'ready':
                skipped += 1
                continue
            row = dict(activity_id=aid, activity_url=f'{client.origin}/crm/activity/?id={aid}',
                       manager_id=a.get('RESPONSIBLE_ID'), manager_name=users.get(str(a.get('RESPONSIBLE_ID')), ''),
                       start_time=a.get('START_TIME'), phone=', '.join(dict.fromkeys(p for p in phones if p)),
                       duration_seconds=duration, duration_source='telephony_max_leg' if durations else 'unknown',
                       call_ids=' | '.join(str(s.get('CALL_ID') or '') for s in stats),
                       record_file_ids=' | '.join(str(s.get('RECORD_FILE_ID') or '') for s in stats),
                       owner_type_id=a.get('OWNER_TYPE_ID'), owner_id=a.get('OWNER_ID'), subject=a.get('SUBJECT'),
                       transcript_status=status, error_code=error, transcription=text)
            writer.writerow({k: safe_cell(v) for k, v in row.items()})
            stream.flush()
            count += 1
            logging.info('Выгружено дел: %d', count)
    os.replace(partial, output)
    logging.info('Готово. Строк: %d; пропущено без текста: %d; ошибок расшифровки: %d', count, skipped, errors)
    return 2 if errors else 0


def main():
    p = argparse.ArgumentParser(description='Выгрузка CRM-звонков и готовых транскрипций Битрикс24')
    p.add_argument('--manager', help='ФИО или несколько частей имени; все совпадения')
    p.add_argument('--date-from', help='YYYY-MM-DD или ISO datetime; включительно')
    p.add_argument('--date-to', help='YYYY-MM-DD включительно; datetime — исключительная граница')
    p.add_argument('--offset', default='+03:00', help='Часовой пояс дат без смещения, по умолчанию +03:00')
    p.add_argument('--min-duration', type=int, help='Секунды, включительно')
    p.add_argument('--max-duration', type=int, help='Секунды, включительно')
    p.add_argument('--phone', help='Поиск по вхождению цифр номера')
    p.add_argument('--call', type=activity_id, help='ID CRM-дела либо ссылка на дело')
    p.add_argument('--output', default='exports/calls.csv')
    p.add_argument('--include-unavailable', action='store_true', help='Также включать звонки без готового текста и ошибки (диагностика)')
    p.add_argument('--rate', type=float, default=1.0, help='Запросов/с, максимум 2')
    args = p.parse_args()
    try:
        if not 0 < args.rate <= 2:
            raise ValueError('Частота должна быть больше 0 и не больше 2.')
        if not re.fullmatch(r'[+-]\d{2}:\d{2}', args.offset):
            raise ValueError('Смещение: +03:00.')
        args.since = boundary(args.date_from, offset=args.offset)
        args.until = boundary(args.date_to, end=True, offset=args.offset)
        if args.since and args.until and args.since >= args.until:
            raise ValueError('Неверный диапазон дат.')
        if any(v is not None and v < 0 for v in (args.min_duration, args.max_duration)):
            raise ValueError('Длительность не может быть отрицательной.')
        if args.min_duration is not None and args.max_duration is not None and args.min_duration > args.max_duration:
            raise ValueError('Минимальная длительность больше максимальной.')
        if args.phone and not re.sub(r'\D', '', args.phone):
            raise ValueError('Телефон должен содержать цифры.')
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s',
                            handlers=[logging.FileHandler('export.log', encoding='utf-8'), logging.StreamHandler()])
        webhook = os.environ.get('BITRIX_WEBHOOK') or getpass.getpass('Вебхук (ввод скрыт): ')
        return export(Client(webhook, args.rate), args)
    except (ApiError, ValueError) as exc:
        logging.error('%s', exc)
        return 1
    except KeyboardInterrupt:
        logging.error('Остановлено. Незавершённые данные сохранены в .partial.')
        return 130
    except Exception:
        logging.error('Сбой обработки или записи файла. Подробности скрыты для защиты секретов. Проверьте права и формат ответа API.')
        return 1


if __name__ == '__main__':
    sys.exit(main())
