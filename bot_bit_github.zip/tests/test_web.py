import json
import threading
import unittest
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from web_app import handler_factory, make_args


class WebTests(unittest.TestCase):
    def test_local_session_and_page(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler_factory(None, 'session-test'))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        conn = HTTPConnection('127.0.0.1', server.server_port)
        try:
            conn.request('GET', '/')
            response = conn.getresponse()
            self.assertEqual(response.status, 200)
            self.assertIn('Подключение к Битрикс24', response.read().decode())
            conn.request('GET', '/browser_export.js')
            response = conn.getresponse()
            self.assertEqual(response.status, 200)
            self.assertIn(b'createSession', response.read())
            conn.request('GET', '/status')
            response = conn.getresponse()
            self.assertEqual(response.status, 403)
            response.read()
            conn.request('GET', '/status', headers={'X-Session': 'session-test'})
            response = conn.getresponse()
            self.assertEqual(json.loads(response.read())['status'], 'idle')
            conn.request('POST', '/export', '{}', headers={'X-Session': 'session-test', 'Origin': 'https://other.example'})
            response = conn.getresponse()
            self.assertEqual(response.status, 403)
            response.read()
        finally:
            conn.close()
            server.shutdown()
            server.server_close()

    def test_filters(self):
        args = make_args({'date_from': '2026-11-01', 'date_to': '2026-11-10', 'min_duration': '30'}, 'a.csv')
        self.assertFalse(args.include_unavailable)
        self.assertEqual(args.until.day, 11)
        with self.assertRaises(ValueError):
            make_args({'min_duration': '100', 'max_duration': '30'}, 'a.csv')
