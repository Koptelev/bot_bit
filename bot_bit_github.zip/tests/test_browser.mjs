import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const source = readFileSync(new URL('../web/browser_export.js', import.meta.url), 'utf8');
const {parseCall, csvCell, browserExport} = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));
assert.equal(parseCall('https://example.org/crm/activity/?id=123'), '123');
assert.throws(() => parseCall('https://example.org/crm/deal/details/123/'));
assert.equal(csvCell('=SUM(1)'), '"\'=SUM(1)"');
assert.equal(csvCell('a"b\nc'), '"a""b\nc"');
const originalFetch = globalThis.fetch;
const originalTimeout = globalThis.setTimeout;
globalThis.setTimeout = fn => originalTimeout(fn, 0);
let pages = 0;
globalThis.fetch = async (url, options) => {
  assert.equal(options.credentials, 'omit');
  assert.equal(options.redirect, 'error');
  const body = options.body;
  if(url.includes('user.get')) return {ok:true, json:async()=>({result:[{ID:7,LAST_NAME:'Иванов',NAME:'Иван'}]})};
  if(url.includes('crm.activity.list')) {
    assert.equal(body.get('filter[RESPONSIBLE_ID][0]'), '7');
    const next = pages++ === 0;
    return {ok:true,json:async()=>({result:[{ID:next?1:2,RESPONSIBLE_ID:7}],...(next?{next:50}:{})})};
  }
  if(url.includes('voximplant.statistic.get')) return {ok:true,json:async()=>({result:[{CALL_DURATION:60,PHONE_NUMBER:'+7999'}]})};
  return {ok:true,json:async()=>({result:body.get('activityId')==='1'?{transcription:'Привет; мир\nСтрока 2'}:null})};
};
try {
  const r = await browserExport({webhook:'https://example.org/rest/1/SECRET/',manager:'Иванов',phone:'999',call:'',date_from:'2026-11-01',date_to:'2026-11-10',min_duration:'30',max_duration:''},()=>{},new AbortController().signal);
  assert.equal(r.ready,1);assert.equal(r.missing,1);assert.equal(r.checked,2);
  assert.equal(new Uint8Array(await r.blob.arrayBuffer())[0],0xef);
  assert.ok((await r.blob.text()).includes('Привет; мир\nСтрока 2'));
  assert.ok(!(await r.blob.text()).includes('SECRET'));
} finally {globalThis.fetch=originalFetch;globalThis.setTimeout=originalTimeout;}
console.log('Browser export tests passed');
