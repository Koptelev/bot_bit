import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const source = readFileSync(new URL('../web/browser_export.js', import.meta.url), 'utf8');
const {parseCall, csvCell, createSession} = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));
assert.equal(parseCall('https://example.org/crm/activity/?id=123'), '123');
assert.throws(() => parseCall('https://example.org/crm/deal/details/123/'));
assert.equal(csvCell('=SUM(1)'), '"\'=SUM(1)"');
const originalFetch = globalThis.fetch, originalTimeout = globalThis.setTimeout;
globalThis.setTimeout = fn => originalTimeout(fn, 0);
const transcripts = [], stats = []; let listRequests = 0;
globalThis.fetch = async (url, options) => {
  assert.equal(options.credentials, 'omit'); assert.equal(options.redirect, 'error');
  const body = options.body;
  const ok = result => ({ok:true,json:async()=>({result})});
  if(url.includes('user.get')) return ok([{ID:7,LAST_NAME:'Иванов'}, {ID:8,LAST_NAME:'Петров'}]);
  if(url.includes('crm.activity.list')) {
    if(body.get('filter[ID]')==='0') return ok([]);
    listRequests++;
    assert.ok(body.get('filter[>=START_TIME]'));
    if(body.get('start')==='0') return {ok:true,json:async()=>({result:[{ID:1,RESPONSIBLE_ID:7},{ID:2,RESPONSIBLE_ID:8}],next:50})};
    return ok([{ID:3,RESPONSIBLE_ID:7},{ID:4,RESPONSIBLE_ID:7}]);
  }
  if(url.includes('voximplant.statistic.get')) {
    const id=body.get('FILTER[CRM_ACTIVITY_ID]');stats.push(id);
    return ok(id==='0'?[]:[{CALL_DURATION:id==='4'?10:60,PHONE_NUMBER:'+7999'}]);
  }
  const id=body.get('activityId');transcripts.push(id);
  return ok(id==='1'?{transcription:'Привет; мир\nСтрока 2'}:null);
};
try {
  const session=createSession('https://example.org/rest/1/SECRET/');
  await session.verify();
  const input={date_from:'2026-11-01',date_to:'2026-11-10',manager_ids:['7'],min_duration:'30',max_duration:'',phone:'',call:''};
  const managers=await session.discover(input);
  assert.deepEqual(managers.map(m=>[m.id,m.count]),[['7',3],['8',1]]);
  assert.equal(transcripts.length,0);assert.deepEqual(stats,['0']);
  const r=await session.export(input);
  assert.equal(r.ready,1);assert.equal(r.missing,1);
  assert.deepEqual(transcripts,['1','3']);
  assert.equal(listRequests,2);
  assert.equal(new Uint8Array(await r.blob.arrayBuffer())[0],0xef);
  assert.ok((await r.blob.text()).includes('Привет; мир\nСтрока 2'));
  assert.ok(!(await r.blob.text()).includes('SECRET'));
  await assert.rejects(()=>session.export({...input,manager_ids:[]}));
  await assert.rejects(()=>session.export({...input,date_to:'2026-11-11'}));
  console.log('Staged workflow and selective transcript tests passed');
} finally {globalThis.fetch=originalFetch;globalThis.setTimeout=originalTimeout;}
