import argparse
import csv
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import bitrix_export as b


class Tests(unittest.TestCase):
    def test_pagination_and_loop(self):
        c = b.Client('https://example.org/rest/1/secret/')
        with patch.object(c, 'call', side_effect=[{'result': [1], 'next': 50}, {'result': [2]}]):
            self.assertEqual(list(c.pages('x', {})), [1, 2])
        with patch.object(c, 'call', return_value={'result': [], 'next': 0}):
            with self.assertRaises(b.ApiError):
                list(c.pages('x', {}))

    def test_dates_and_ids(self):
        self.assertEqual(b.boundary('2026-11-10', True).isoformat(), '2026-11-11T00:00:00+03:00')
        self.assertEqual(b.activity_id('https://example.org/crm/activity/?activity_id=123'), 123)
        with self.assertRaises(argparse.ArgumentTypeError):
            b.activity_id('https://example.org/crm/deal/details/123/')

    def test_export(self):
        class Fake:
            origin = 'https://example.org'
            def pages(self, method, params):
                if method == 'user.get':
                    return iter([{'ID': 7, 'LAST_NAME': 'Иванов', 'NAME': 'Иван'}])
                if method == 'crm.activity.list':
                    return iter([{'ID': i, 'RESPONSIBLE_ID': 7, 'SUBJECT': '=cmd',
                                  'COMMUNICATIONS': []} for i in range(1, 4)])
                return iter([{'CALL_DURATION': 60, 'PHONE_NUMBER': '+79991234567', 'CALL_ID': 'a'}])
            def call(self, method, params):
                i = params['activityId']
                if i == 3:
                    raise b.ApiError('ACCESS_DENIED')
                return {'result': {'transcription': 'Привет; мир\nВторая строка'} if i == 1 else None}
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as d:
            args = argparse.Namespace(manager='Иван Иванов', call=None, since=None, until=None,
                                      output=str(Path(d) / 'calls.csv'), phone='999', min_duration=30, max_duration=120,
                                      include_unavailable=True)
            self.assertEqual(b.export(Fake(), args), 2)
            self.assertTrue(Path(args.output).read_bytes().startswith(b'\xef\xbb\xbf'))
            with open(args.output, encoding='utf-8-sig', newline='') as f:
                rows = list(csv.DictReader(f, delimiter=';'))
            self.assertEqual([r['transcript_status'] for r in rows], ['ready', 'unavailable', 'error'])
            self.assertEqual(rows[0]['transcription'], 'Привет; мир\nВторая строка')
            self.assertEqual(rows[0]['subject'], "'=cmd")
            self.assertFalse(Path(args.output + '.partial').exists())
            args.include_unavailable = False
            self.assertEqual(b.export(Fake(), args), 2)
            with open(args.output, encoding='utf-8-sig', newline='') as f:
                ready = list(csv.DictReader(f, delimiter=';'))
            self.assertEqual(len(ready), 1)
            self.assertEqual(ready[0]['transcript_status'], 'ready')

    def test_secret_not_in_error(self):
        c = b.Client('https://example.org/rest/1/SECRET/')
        with patch.object(c.opener, 'open', side_effect=b.URLError('https://example.org/rest/1/SECRET/')):
            c.retries = 0
            with self.assertRaisesRegex(b.ApiError, '^NETWORK_ERROR$'):
                c.call('test', {})


if __name__ == '__main__':
    unittest.main()
